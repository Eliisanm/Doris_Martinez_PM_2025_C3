#include <stdio.h>
#include <stdlib.h>

/* Suma reales.
El programa lee cadenas de caracteres de un archivo, detecta aquellas que
comienzan con n�meros, los suma y calcula el promedio de los mismos. */

void sumypro(FILE *); /* Prototipo de funci�n. */

int main(void) /* Cambiado de void main(void) a int main(void) */
{
    FILE *ap;
    if ((ap = fopen("C:\\Users\\sv988\\Desktop\\programacion 2\\Tarea #6\\Capitulo #9\\programa RP9.5\\bin\\Debug\\arc2.txt", "r")) != NULL)
    {
        sumypro(ap);
        /* Se llama a la funci�n sumypro. Se pasa el archivo ap como par�metro. */
        fclose(ap);
    }
    else
    {
        printf("No se puede abrir el archivo\n");
    }

    return 0;
}

void sumypro(FILE *ap1)
/* Esta funci�n lee cadenas de caracteres de un archivo, detecta aquellas
que comienzan con n�meros, y obtiene la suma y el promedio de dichos
n�meros. */
{
    char cad[30];
    int i = 0;
    float sum = 0.0, r;

    /* La funci�n fgets y el uso de feof en el bucle pueden tener problemas
    para leer la �ltima l�nea si termina sin salto de l�nea. Se mantiene
    el c�digo original, pero se recomienda el patr�n de lectura
    "while (fgets(...) != NULL)" para archivos. */
    while (!feof (ap1))
    {
        fgets(cad, 30, ap1); /* Se lee la cadena del archivo. */

        /* Si fgets falla al leer (por fin de archivo o error), y luego se
        llama a feof, puede haber un comportamiento inesperado.
        Una verificaci�n simple es: */
        if (feof(ap1) && cad[0] == '\0')
        {
            break;
        }

        r = atof(cad);

        /* Recuerda que la funci�n atof convierte una cadena de caracteres que
        contiene n�meros reales a un valor de tipo double. Si la cadena comienza
        con otro caracter o no contiene n�meros, regresa 0. */
        if (r != 0.0) /* Usamos r != 0.0 para ser m�s claros, ya que 0 es el valor de retorno por defecto si no es un n�mero. */
        {
            i++;
            sum += r;
        }
        /* Nota: Si la l�nea contiene el n�mero 0.0, ser� contado y sumado,
        pero si la l�nea no contiene n�meros, tambi�n ser� evaluado como 0.0.
        Para un chequeo m�s estricto si la cadena empieza con un d�gito
        se usar�a isdigit(cad[0]). */
    }

    printf("\nSuma: %.2f", sum);
    if (i) /* Si el valor de i es distinto de cero, calcula el promedio. */
    {
        printf("\nPromedio: %.2f", sum / i);
    }
}
